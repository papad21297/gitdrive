export default function BlogeFirst() {
  return (
    <>
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>Blog Page #1</span>
    </>
  )
}