export default function Blog() {
  return (
    <>
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>Blog Page</span>
    </>
  )
}