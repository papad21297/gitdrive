export default function About() {
  return (
    <>
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>About Page</span>
    </>
  )
}