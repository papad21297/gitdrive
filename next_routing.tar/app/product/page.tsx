export default function Product() {
  return (
    <>
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>Product #1</span>
	  <br />
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>Product #2</span>
	  <br />
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>Product #3</span>
    </>
  )
}