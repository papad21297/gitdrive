export default function Profile() {
  return (
    <>
      <span style={{
        fontSize: '72px',
        fontWeight: 700
      }}>Profile Page</span>
    </>
  )
}